


  '==============
  'WAVEFORM AUDIO
  '==============

  /*
  Wave audio
  https://ccrma.stanford.edu/courses/422/projects/WaveFormat/
  '
  http://msdn.microsoft.com/en-us/library/ms713619.aspx
  functions
  http://msdn.microsoft.com/en-us/library/ms713504.aspx
  example
  http://msdn.microsoft.com/en-us/library/ms708482.aspx
  */

  #case capital

  typedef byte    BYTE
  typedef word    WORD
  typedef sys     HANDLE,DWORD_PTR,*LPHWAVEOUT
  typedef long    LONG,MMRESULT,MCIERROR
  typedef dword   DWORD,UINT,MMVERSION,*UINT_PTR,*LPDWORD
  typedef zstring TCHAR,*LPSTR,*LPTSTR,*LPCTSTR


  'FROM MMSYSTEM.H

  /* types for wType field in MMTIME struct */
  #define TIME_MS         0x0001  /* time in milliseconds */
  #define TIME_SAMPLES    0x0002  /* number of wave samples */
  #define TIME_BYTES      0x0004  /* current byte offset */
  #define TIME_SMPTE      0x0008  /* SMPTE time */
  #define TIME_MIDI       0x0010  /* MIDI time */
  #define TIME_TICKS      0x0020  /* Ticks within MIDI stream */


  /* defines for dwFormat field of WAVEINCAPS and WAVEOUTCAPS */
  #define WAVE_INVALIDFORMAT     0x00000000       /* invalid format */
  #define WAVE_FORMAT_1M08       0x00000001       /* 11.025 kHz, Mono,   8-bit  */
  #define WAVE_FORMAT_1S08       0x00000002       /* 11.025 kHz, Stereo, 8-bit  */
  #define WAVE_FORMAT_1M16       0x00000004       /* 11.025 kHz, Mono,   16-bit */
  #define WAVE_FORMAT_1S16       0x00000008       /* 11.025 kHz, Stereo, 16-bit */
  #define WAVE_FORMAT_2M08       0x00000010       /* 22.05  kHz, Mono,   8-bit  */
  #define WAVE_FORMAT_2S08       0x00000020       /* 22.05  kHz, Stereo, 8-bit  */
  #define WAVE_FORMAT_2M16       0x00000040       /* 22.05  kHz, Mono,   16-bit */
  #define WAVE_FORMAT_2S16       0x00000080       /* 22.05  kHz, Stereo, 16-bit */
  #define WAVE_FORMAT_4M08       0x00000100       /* 44.1   kHz, Mono,   8-bit  */
  #define WAVE_FORMAT_4S08       0x00000200       /* 44.1   kHz, Stereo, 8-bit  */
  #define WAVE_FORMAT_4M16       0x00000400       /* 44.1   kHz, Mono,   16-bit */
  #define WAVE_FORMAT_4S16       0x00000800       /* 44.1   kHz, Stereo, 16-bit */

  #define WAVE_FORMAT_44M08      0x00000100       /* 44.1   kHz, Mono,   8-bit  */
  #define WAVE_FORMAT_44S08      0x00000200       /* 44.1   kHz, Stereo, 8-bit  */
  #define WAVE_FORMAT_44M16      0x00000400       /* 44.1   kHz, Mono,   16-bit */
  #define WAVE_FORMAT_44S16      0x00000800       /* 44.1   kHz, Stereo, 16-bit */
  #define WAVE_FORMAT_48M08      0x00001000       /* 48     kHz, Mono,   8-bit  */
  #define WAVE_FORMAT_48S08      0x00002000       /* 48     kHz, Stereo, 8-bit  */
  #define WAVE_FORMAT_48M16      0x00004000       /* 48     kHz, Mono,   16-bit */
  #define WAVE_FORMAT_48S16      0x00008000       /* 48     kHz, Stereo, 16-bit */
  #define WAVE_FORMAT_96M08      0x00010000       /* 96     kHz, Mono,   8-bit  */
  #define WAVE_FORMAT_96S08      0x00020000       /* 96     kHz, Stereo, 8-bit  */
  #define WAVE_FORMAT_96M16      0x00040000       /* 96     kHz, Mono,   16-bit */
  #define WAVE_FORMAT_96S16      0x00080000       /* 96     kHz, Stereo, 16-bit */

  /* flags for wFormatTag field of WAVEFORMAT */

  #define WAVE_FORMAT_PCM     1

/* flags used with waveOutOpen(), waveInOpen(), midiInOpen(), and */
/* midiOutOpen() to specify the type of the dwCallback parameter. */

#define CALLBACK_TYPEMASK   0x00070000l    /* callback type mask */
#define CALLBACK_NULL       0x00000000l    /* no callback */
#define CALLBACK_WINDOW     0x00010000l    /* dwCallback is a HWND */
#define CALLBACK_TASK       0x00020000l    /* dwCallback is a HTASK */
#define CALLBACK_FUNCTION   0x00030000l    /* dwCallback is a FARPROC */
#define CALLBACK_THREAD     (CALLBACK_TASK)/* thread ID replaces 16 bit task */
#define CALLBACK_EVENT      0x00050000l    /* dwCallback is an EVENT Handle */

#define WAVE_MAPPER     -1
'((UINT)-1)


/* general error return values */
#define MMSYSERR_NOERROR      0                    /* no error */
#define MMSYSERR_ERROR        (MMSYSERR_BASE + 1)  /* unspecified error */
#define MMSYSERR_BADDEVICEID  (MMSYSERR_BASE + 2)  /* device ID out of range */
#define MMSYSERR_NOTENABLED   (MMSYSERR_BASE + 3)  /* driver failed enable */
#define MMSYSERR_ALLOCATED    (MMSYSERR_BASE + 4)  /* device already allocated */
#define MMSYSERR_INVALHANDLE  (MMSYSERR_BASE + 5)  /* device handle is invalid */
#define MMSYSERR_NODRIVER     (MMSYSERR_BASE + 6)  /* no device driver present */
#define MMSYSERR_NOMEM        (MMSYSERR_BASE + 7)  /* memory allocation error */
#define MMSYSERR_NOTSUPPORTED (MMSYSERR_BASE + 8)  /* function isn't supported */
#define MMSYSERR_BADERRNUM    (MMSYSERR_BASE + 9)  /* error value out of range */
#define MMSYSERR_INVALFLAG    (MMSYSERR_BASE + 10) /* invalid flag passed */
#define MMSYSERR_INVALPARAM   (MMSYSERR_BASE + 11) /* invalid parameter passed */
#define MMSYSERR_HANDLEBUSY   (MMSYSERR_BASE + 12) /* handle being used */
                                                   /* simultaneously on another */
                                                   /* thread (eg callback) */
#define MMSYSERR_INVALIDALIAS (MMSYSERR_BASE + 13) /* specified alias not found */
#define MMSYSERR_BADDB        (MMSYSERR_BASE + 14) /* bad registry database */
#define MMSYSERR_KEYNOTFOUND  (MMSYSERR_BASE + 15) /* registry key not found */
#define MMSYSERR_READERROR    (MMSYSERR_BASE + 16) /* registry read error */
#define MMSYSERR_WRITEERROR   (MMSYSERR_BASE + 17) /* registry write error */
#define MMSYSERR_DELETEERROR  (MMSYSERR_BASE + 18) /* registry delete error */
#define MMSYSERR_VALNOTFOUND  (MMSYSERR_BASE + 19) /* registry value not found */
#define MMSYSERR_NODRIVERCB   (MMSYSERR_BASE + 20) /* driver does not call DriverCallback */
#define MMSYSERR_MOREDATA     (MMSYSERR_BASE + 21) /* more data to be returned */
#define MMSYSERR_LASTERROR    (MMSYSERR_BASE + 21) /* last error in range */


/* flags for dwFlags field of WAVEHDR */
#define WHDR_DONE       0x00000001  /* done bit */
#define WHDR_PREPARED   0x00000002  /* set if this header has been prepared */
#define WHDR_BEGINLOOP  0x00000004  /* loop start block */
#define WHDR_ENDLOOP    0x00000008  /* loop end block */
#define WHDR_INQUEUE    0x00000010  /* reserved for driver */

#define MM_WOM_OPEN         0x3BB           /* waveform output */
#define MM_WOM_CLOSE        0x3BC
#define MM_WOM_DONE         0x3BD



  typedef struct waveformatex_tag { 
    WORD  wFormatTag; 
    WORD  nChannels; 
    DWORD nSamplesPerSec; 
    DWORD nAvgBytesPerSec; 
    WORD  nBlockAlign; 
    WORD  wBitsPerSample; 
    WORD  cbSize; 
  } WAVEFORMATEX,*LPCWAVEFORMATEX;


  typedef struct wavehdr_tag { 
    LPSTR      lpData; 
    DWORD      dwBufferLength; 
    DWORD      dwBytesRecorded; 
    DWORD_PTR  dwUser; 
    DWORD      dwFlags; 
    DWORD      dwLoops; 
    struct wavehdr_tag * lpNext;
    DWORD_PTR reserved; 
  } WAVEHDR, *LPWAVEHDR;


  typedef struct mmtime_tag { 
    UINT wType; 
    union {
        DWORD ms; 
        DWORD sample; 
        DWORD cb; 
        DWORD ticks; 
        struct { 
            BYTE hour; 
            BYTE min; 
            BYTE sec; 
            BYTE frame; 
            BYTE fps; 
            BYTE dummy; 
            BYTE pad[2] 
        } smpte; 
        struct { 
            DWORD songptrpos; 
        } midi; 
    } u; 
  } MMTIME,*LPMMTIME;


  typedef struct { 
    WORD      wMid; 
    WORD      wPid; 
    MMVERSION vDriverVersion; 
    TCHAR     szPname[MAXPNAMELEN]; 
    DWORD     dwFormats; 
    WORD      wChannels; 
    WORD      wReserved1; 
  } WAVEINCAPS; 


  typedef struct { 
    WORD      wMid; 
    WORD      wPid; 
    MMVERSION vDriverVersion; 
    TCHAR     szPname[MAXPNAMELEN]; 
    DWORD     dwFormats; 
    WORD      wChannels; 
    WORD      wReserved1; 
    DWORD     dwSupport; 
  } WAVEOUTCAPS,*LPWAVEOUTCAPSA; 


  'add hoc definitions
  #define WINMMAPI
  #define WINAPI
  #define __in
  #define __out
  #define __in_opt
  #define __out_opt
  #define __inout_bcount(cbwh)
  #define __out_ecount(cchText)


  extern lib "Winmm.dll"
  WINMMAPI UINT WINAPI waveOutGetNumDevs(void);
  WINMMAPI MMRESULT WINAPI waveOutGetDevCapsA( __in UINT_PTR uDeviceID, __out LPWAVEOUTCAPSA pwoc, __in UINT cbwoc);
  WINMMAPI MMRESULT WINAPI waveOutGetVolume( __in_opt HWAVEOUT hwo, __out LPDWORD pdwVolume);
  WINMMAPI MMRESULT WINAPI waveOutSetVolume( __in_opt HWAVEOUT hwo, __in DWORD dwVolume);
  WINMMAPI MMRESULT WINAPI waveOutGetErrorTextA( __in MMRESULT mmrError, __out_ecount(cchText) LPSTR pszText, __in UINT cchText);
  WINMMAPI MMRESULT WINAPI waveOutGetErrorTextW( __in MMRESULT mmrError, __out_ecount(cchText) LPWSTR pszText, __in UINT cchText);
  WINMMAPI MMRESULT WINAPI waveOutOpen
  (
    __out_opt LPHWAVEOUT phwo,
    __in UINT uDeviceID,
    __in LPCWAVEFORMATEX pwfx,
    __in_opt DWORD_PTR dwCallback,
    __in_opt DWORD_PTR dwInstance,
    __in DWORD fdwOpen
  );
  WINMMAPI MMRESULT WINAPI waveOutClose( __in HWAVEOUT hwo);
  WINMMAPI MMRESULT WINAPI waveOutPrepareHeader( __in HWAVEOUT hwo, __inout_bcount(cbwh) LPWAVEHDR pwh,  __in UINT cbwh);
  WINMMAPI MMRESULT WINAPI waveOutUnprepareHeader( __in HWAVEOUT hwo, __inout_bcount(cbwh) LPWAVEHDR pwh, __in UINT cbwh);
  WINMMAPI MMRESULT WINAPI waveOutWrite( __in HWAVEOUT hwo, __inout_bcount(cbwh) LPWAVEHDR pwh, __in UINT cbwh);
  WINMMAPI MMRESULT WINAPI waveOutPause( __in HWAVEOUT hwo);
  WINMMAPI MMRESULT WINAPI waveOutRestart( __in HWAVEOUT hwo);
  WINMMAPI MMRESULT WINAPI waveOutReset( __in HWAVEOUT hwo);
  WINMMAPI MMRESULT WINAPI waveOutBreakLoop( __in HWAVEOUT hwo);
  WINMMAPI MMRESULT WINAPI waveOutGetPosition( __in HWAVEOUT hwo, __inout_bcount(cbmmt) LPMMTIME pmmt, __in UINT cbmmt);
  WINMMAPI MMRESULT WINAPI waveOutGetPitch( __in HWAVEOUT hwo, __out LPDWORD pdwPitch);
  WINMMAPI MMRESULT WINAPI waveOutSetPitch( __in HWAVEOUT hwo, __in DWORD dwPitch);
  WINMMAPI MMRESULT WINAPI waveOutGetPlaybackRate( __in HWAVEOUT hwo, __out LPDWORD pdwRate);
  WINMMAPI MMRESULT WINAPI waveOutSetPlaybackRate( __in HWAVEOUT hwo, __in DWORD dwRate);
  WINMMAPI MMRESULT WINAPI waveOutGetID( __in HWAVEOUT hwo, __out LPUINT puDeviceID);

   MCIERROR mciSendString( LPCTSTR lpszCommand, LPTSTR lpszReturnString, UINT cchReturn, HANDLE hwndCallback );
  'mciSendString (zstring *lpstrCommand, *lpstrReturnString, dword RetrunLength, hWndCallback) as sys


  end extern




